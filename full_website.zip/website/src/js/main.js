(function() {

	$('.page-nav__hamburger').on('click', function() {
		$('.page-nav__ul').toggle();
	});

})();